package com.mentalfrostbyte.jello.music.music;

public class ChannelObj {

	public String name;
	public String id;
	
	public ChannelObj(String n, String i){
		name = n;
		id = i;
	}
	
}
