package net.minecraft.block;

public class BlockRedFlower extends BlockFlower
{
    

    public BlockFlower.EnumFlowerColor func_176495_j()
    {
        return BlockFlower.EnumFlowerColor.RED;
    }
}
